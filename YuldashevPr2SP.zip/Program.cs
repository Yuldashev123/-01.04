﻿using System.IO;

foreach(var driveInfo in DriveInfo.GetDrives())
{
    Console.WriteLine( driveInfo.Name);


    
    Console.WriteLine("Общее место диска в байтах: " + driveInfo.TotalSize);
    Console.WriteLine("Общее место диска в килобайтах: " + driveInfo.TotalSize/1024);
    Console.WriteLine("Общее место диска в мегабайтах: " + driveInfo.TotalSize/1024/1024);
    Console.WriteLine("Общее место диска в гигабайтах: " + driveInfo.TotalSize/1024/1024/1024);

    Console.WriteLine("Свободное место диска в байтах: " + driveInfo.AvailableFreeSpace);
    Console.WriteLine("Свободное место диска в килобайтах: " + driveInfo.AvailableFreeSpace/1024);
    Console.WriteLine("Свободное место диска в мегабайтах: " + driveInfo.AvailableFreeSpace/1024/1024);
    Console.WriteLine("Свободное место диска в гигабайтах: " + driveInfo.AvailableFreeSpace/1024/1024/1024);

    



    Console.WriteLine( driveInfo.VolumeLabel);

}

foreach(var dir in Directory.GetDirectories("C:\\"))
{
    Console.WriteLine(dir);
}

foreach (var file in Directory.GetFiles("C:\\").Where(file => file.EndsWith(".sys")))
{
    Console.WriteLine(file);
}

string path = @"C:\Users\Student\Desktop\Yuldashev.txt";
string text = "Boar";

// полная перезапись файла 
using (StreamWriter writer = new StreamWriter(path, false))
{
    await writer.WriteLineAsync(text);
}

// добавление в файл
using (StreamWriter writer = new StreamWriter(path, true))
{
    await writer.WriteLineAsync("lvl 2");
    await writer.WriteAsync("2500 gold");
}

// асинхронное чтение
using (StreamReader reader = new StreamReader(path))
{
    Console.WriteLine(await reader.ReadToEndAsync());
}


