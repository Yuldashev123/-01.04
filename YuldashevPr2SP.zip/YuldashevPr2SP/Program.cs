﻿using System.IO;

foreach(var driveInfo in DriveInfo.GetDrives())
{
    Console.WriteLine( driveInfo.Name);



    Console.WriteLine( driveInfo.TotalSize/1024);
    Console.WriteLine( driveInfo.TotalSize/1024/1024);
    Console.WriteLine( driveInfo.TotalSize/1024/1024/1024);
    Console.WriteLine( driveInfo.TotalSize/1024/1024/1024/1024);

    Console.WriteLine( driveInfo.AvailableFreeSpace);





    Console.WriteLine( driveInfo.VolumeLabel);

}

foreach(var dir in Directory.GetDirectories("C:\\"))
{
    Console.WriteLine(dir);
}

foreach (var dir in Directory.GetFiles("C:\\"))
{
    Console.WriteLine(dir);
}



