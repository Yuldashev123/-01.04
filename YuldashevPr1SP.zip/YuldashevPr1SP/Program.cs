﻿using System.Management;

ManagementObjectSearcher searcher = new ManagementObjectSearcher("select * from Win32_Registry");

foreach (ManagementObject obj in searcher.Get())
{
    Console.WriteLine(String.Format("|{0,25}|{1,10}||{2,10}| |{3,10}| |{4,10}| ", obj.GetPropertyValue("Caption"), obj.GetPropertyValue("Description"), obj.GetPropertyValue("InstallDate"),obj.GetPropertyValue("Status"),obj.GetPropertyValue("CurrentSize")));
}

Console.ReadLine();
Console.Clear();


ManagementObjectSearcher searcher2 = new ManagementObjectSearcher("select * from Win32_CodecFile");

foreach (ManagementObject obj in searcher2.Get())
{
    Console.WriteLine(String.Format("|{0,25}|{1,10}||{2,10}| |{3,10}| |{4,10}| ", obj.GetPropertyValue("AccessMask"), obj.GetPropertyValue("Archive"), obj.GetPropertyValue("Compressed"), obj.GetPropertyValue("CreationDate"), obj.GetPropertyValue("EightDotThreeFileName")));
}

Console.ReadLine();
Console.Clear();

ManagementObjectSearcher searcher3 = new ManagementObjectSearcher("select * from Win32_Session");

foreach (ManagementObject obj in searcher3.Get())
{
    Console.WriteLine(String.Format("|{0,25}|{1,10}||{2,10}| |{3,10}| |{4,10}| ", obj.GetPropertyValue("Caption"), obj.GetPropertyValue("Description"), obj.GetPropertyValue("InstallDate"), obj.GetPropertyValue("Status"), obj.GetPropertyValue("StartTime")));
}

Console.ReadLine();
Console.Clear();

ManagementObjectSearcher searcher4 = new ManagementObjectSearcher("select * from Win32_SystemAccount");

foreach (ManagementObject obj in searcher4.Get())
{
    Console.WriteLine(String.Format("|{0,25}|{1,10}||{2,10}| |{3,10}| |{4,10}| ", obj.GetPropertyValue("Caption"), obj.GetPropertyValue("Description"), obj.GetPropertyValue("InstallDate"), obj.GetPropertyValue("Status"), obj.GetPropertyValue("SID")));
}

Console.ReadLine();
Console.Clear();

ManagementObjectSearcher searcher5 = new ManagementObjectSearcher("select * from Win32_Service");

foreach (ManagementObject obj in searcher5.Get())
{
    Console.WriteLine(String.Format("|{0,25}|{1,10}||{2,10}| |{3,10}| ", obj.GetPropertyValue("Name"), obj.GetPropertyValue("PathName"), obj.GetPropertyValue("DisplayName"), obj.GetPropertyValue("DesktopInteract")));
}