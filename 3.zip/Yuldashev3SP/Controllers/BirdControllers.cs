﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Yuldashev3SP.Contexts;
using Yuldashev3SP.Models;

namespace Yuldashev3SP.Controllers
{
    [ApiController]
    [Route("API/[controller]")]
    public class BirdControllers : ControllerBase
    {
        private MainContext _context;

        public BirdControllers(MainContext context)
        {
            _context = context;
        }

        [HttpGet]
        public async Task<IEnumerable<Bird>> GetAll()
        {
            return await _context.Birds.ToListAsync();
        }

        [HttpGet("{id}")]
        public async Task<Bird> Get(int id)
        {
            return await _context.Birds.FindAsync(id);
        }

        [HttpGet("ByDate/{date}")]
        public async Task<IEnumerable<Bird>> Get(DateTime date)
        {
            return await _context.Birds.Where(bird =>
            bird.OpeningDate.Date == date).ToListAsync();
        }

        [HttpGet("ByCount/")]
        public async Task<IEnumerable<Bird>> GetByCount()
        {
            return await _context.Birds.Where(bird =>
            bird.Count > 50).ToListAsync();
        }

        [HttpGet("ByBirdName/")]
        public async Task<IEnumerable<Bird>> GetByBirdName()
        {
            return await _context.Birds.Where(bird =>
            bird.BirdName.StartsWith("Ку")).ToListAsync();
        }
    }
}
