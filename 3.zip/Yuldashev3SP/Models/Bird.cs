﻿namespace Yuldashev3SP.Models
{
    public class Bird
    {
        public int BirdId { get; set; }
        public string BirdName { get; set; }
        public DateTime OpeningDate { get; set; }
        public string BirdType { get; set; }
        public int Count { get; set; }
    }
}
