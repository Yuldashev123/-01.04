﻿using Microsoft.EntityFrameworkCore;
using Yuldashev3SP.Models;

namespace Yuldashev3SP.Contexts
{
    public class MainContext : DbContext
    {
        public DbSet<Bird> Birds { get; set; }

        public MainContext(DbContextOptions options) : base(options)
        {
            Database.EnsureCreated();
        }
    }
}
