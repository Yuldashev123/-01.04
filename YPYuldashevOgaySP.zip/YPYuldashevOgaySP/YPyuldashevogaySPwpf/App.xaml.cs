﻿using System.Configuration;
using System.Data;
using System.Net.Http;
using System.Windows;
using System.Windows.Media.TextFormatting;
using Microsoft.Extensions.DependencyInjection;
using YPyuldashevogaySPwpf.View;
using YPyuldashevogaySPwpf.ViewModels;
using YuldashevOgayYPApiHttpClient;

namespace YPyuldashevogaySPwpf
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        private IServiceProvider serviceProvider;

        public App()
        {
            ServiceCollection services = new ServiceCollection();
            ConfigureServices(services);
            serviceProvider = services.BuildServiceProvider();
        }

        private void ConfigureServices(ServiceCollection services)
        {
            services.AddHttpClient();
            const string ApiUrl = "http://localhost:5000";
            services.AddSingleton<FuelsHttpClient>(sp =>
            {
                var factory = sp.GetRequiredService<IHttpClientFactory>();
                var client = factory.CreateClient();
                var httpClient = new FuelsHttpClient(ApiUrl, client);
                return httpClient;
            });


            services.AddSingleton<ClientsHttpClient>(sp =>
            {
                var factory = sp.GetRequiredService<IHttpClientFactory>();
                var client = factory.CreateClient();
                var httpClient = new ClientsHttpClient(ApiUrl, client);
                return httpClient;
            });


            services.AddSingleton<SalesHttpClient>(sp =>
            {
                var factory = sp.GetRequiredService<IHttpClientFactory>();
                var client = factory.CreateClient();
                var httpClient = new SalesHttpClient(ApiUrl, client);
                return httpClient;
            });



            services.AddSingleton<SuppliersHttpClient>(sp =>
            {
                var factory = sp.GetRequiredService<IHttpClientFactory>();
                var client = factory.CreateClient();
                var httpClient = new SuppliersHttpClient(ApiUrl, client);
                return httpClient;
            });
            services.AddSingleton<MainWindow>();
            services.AddSingleton<FuelsViewModel>();
            services.AddSingleton<MainViewModel>();
            services.AddSingleton<ClientViewModel>();
            services.AddSingleton<SaleViewModel>();
            services.AddSingleton<SupplierViewModel>();
        }

        private void Application_Startup(object sender, StartupEventArgs e)
        {
            var mainWindow = serviceProvider.GetService<MainWindow>();
            mainWindow.Show();
        }
    }

}
