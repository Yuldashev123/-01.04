﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using YPyuldashevogaySPwpf.ViewModels;
using YPyuldashevogaySPwpf;
using YuldashevOgayYPApiHttpClient;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace YPyuldashevogaySPwpf.ViewModels
{
    public class SaleViewModel : BaseViewModel
    
    {


        private IEnumerable<Sale> _Sale;
        public IEnumerable<Sale> Sales

        {
            get { return _Sale; }
            set { _Sale = value; OnPropertyChanged(); }
        }
        //Временный объект для добавления или изменения
        private Sale _CurrentSale;
        public Sale CurrentSale
        {
            get { return _CurrentSale; }
            set { _CurrentSale = value; OnPropertyChanged(); }
        }
        public DelegateCommand ProcessSaleCommand
        {
            get
            {
                return new DelegateCommand(o =>
                {
                    ProcessSale();
                });
            }
        }
        private void ProcessSale()
        {
            if (CurrentSale.SaleId == 0)
            {
                CreateSale();
            }
            else
            {
                UpdateSale();
            }
        }
        public DelegateCommand ClearSaleCommand
        {
            get
            {
                return new DelegateCommand(o =>
                {
                    ClearSale();
                });
            }
        }
        private void ClearSale()
        {
            CurrentSale = new Sale();
        }
        private void UpdateSale()
        {
            _httpClient.UpdateAsync(CurrentSale);
            GetSale();
        }
        private void CreateSale()
        {
            _httpClient.CreateAsync(CurrentSale);
            GetSale();
        }
        private void DeleteSale(int SaleId)
        {
            _httpClient.DeleteAsync(SaleId);
            GetSale();
        }
        public DelegateCommand DeleteSaleCommand
        {
            get
            {
                return new DelegateCommand(o =>
                {
                    DeleteSale((int)o);
                });
            }
        }
        private void GetSale()
        {
            Sales = _httpClient.GetAllAsync().Result;
        }

        private SalesHttpClient _httpClient;

        public SaleViewModel(SalesHttpClient httpClient)
        {
            _httpClient = httpClient;
            GetSale();
            CurrentSale = new Sale();
        }
    }
}