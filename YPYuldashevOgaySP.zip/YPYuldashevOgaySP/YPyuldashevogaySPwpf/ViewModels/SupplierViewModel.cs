﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using YPyuldashevogaySPwpf.ViewModels;
using YPyuldashevogaySPwpf;
using YuldashevOgayYPApiHttpClient;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace YPyuldashevogaySPwpf.ViewModels
{
    public class SupplierViewModel : BaseViewModel
    { 


        private IEnumerable<Supplier> _Supplier;
        public IEnumerable<Supplier> Suppliers

        {
            get { return _Supplier; }
            set { _Supplier = value; OnPropertyChanged(); }
        }
        //Временный объект для добавления или изменения
        private Supplier _CurrentSupplier;
        public Supplier CurrentSupplier
        {
            get { return _CurrentSupplier; }
            set { _CurrentSupplier = value; OnPropertyChanged(); }
        }
        public DelegateCommand ProcessSupplierCommand
        {
            get
            {
                return new DelegateCommand(o =>
                {
                    ProcessSupplier();
                });
            }
        }
        private void ProcessSupplier()
        {
            if (CurrentSupplier.SupplierId == 0)
            {
                CreateSupplier();
            }
            else
            {
                UpdateSupplier();
            }
        }
        public DelegateCommand ClearSupplierCommand
        {
            get
            {
                return new DelegateCommand(o =>
                {
                    ClearSupplier();
                });
            }
        }
        private void ClearSupplier()
        {
            CurrentSupplier = new Supplier();
        }
        private void UpdateSupplier()
        {
            _httpClient.UpdateAsync(CurrentSupplier);
            GetSupplier();
        }
        private void CreateSupplier()
        {
            _httpClient.CreateAsync(CurrentSupplier);
            GetSupplier();
        }
        private void DeleteSupplier(int SupplierId)
        {
            _httpClient.DeleteAsync(SupplierId);
            GetSupplier();
        }
        public DelegateCommand DeleteSupplierCommand
        {
            get
            {
                return new DelegateCommand(o =>
                {
                    DeleteSupplier((int)o);
                });
            }
        }
        private void GetSupplier()
        {
            Suppliers = _httpClient.GetAllAsync().Result;
        }

        private SuppliersHttpClient _httpClient;

        public SupplierViewModel(SuppliersHttpClient httpClient)
        {
            _httpClient = httpClient;
            GetSupplier();
            CurrentSupplier = new Supplier();
        }
    }
}