﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using YPyuldashevogaySPwpf.ViewModels;
using YPyuldashevogaySPwpf;
using YuldashevOgayYPApiHttpClient;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace YPyuldashevogaySPwpf.ViewModels
{
    public class ClientViewModel : BaseViewModel
    { 


        private IEnumerable<Client> _Client;
        public IEnumerable<Client> Clients

        {
            get { return _Client; }
            set { _Client = value; OnPropertyChanged(); }
        }
        //Временный объект для добавления или изменения
        private Client _CurrentClient;
        public Client CurrentClient
        {
            get { return _CurrentClient; }
            set { _CurrentClient = value; OnPropertyChanged(); }
        }
        public DelegateCommand ProcessClientCommand
        {
            get
            {
                return new DelegateCommand(o =>
                {
                    ProcessClient();
                });
            }
        }
        private void ProcessClient()
        {
            if (CurrentClient.ClientId == 0)
            {
                CreateClient();
            }
            else
            {
                UpdateClient();
            }
        }
        public DelegateCommand ClearClientCommand
        {
            get
            {
                return new DelegateCommand(o =>
                {
                    ClearClient();
                });
            }
        }
        private void ClearClient()
        {
            CurrentClient = new Client();
        }
        private void UpdateClient()
        {
            _httpClient.UpdateAsync(CurrentClient);
            GetClient();
        }
        private void CreateClient()
        {
            _httpClient.CreateAsync(CurrentClient);
            GetClient();
        }
        private void DeleteClient(int ClientId)
        {
            _httpClient.DeleteAsync(ClientId);
            GetClient();
        }
        public DelegateCommand DeleteClientCommand
        {
            get
            {
                return new DelegateCommand(o =>
                {
                    DeleteClient((int)o);
                });
            }
        }
        private void GetClient()
        {
            Clients = _httpClient.GetAllAsync().Result;
        }

        private ClientsHttpClient _httpClient;

        public ClientViewModel(ClientsHttpClient httpClient)
        {
            _httpClient = httpClient;
            GetClient();
            CurrentClient = new Client();
        }
    }
}