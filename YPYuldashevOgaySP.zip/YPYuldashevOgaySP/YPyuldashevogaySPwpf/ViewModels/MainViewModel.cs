﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YPyuldashevogaySPwpf.ViewModels
{
    public class MainViewModel : BaseViewModel
    {
        public SupplierViewModel SupplierViewModel { get; }
        public SaleViewModel SaleViewModel { get; }
        public FuelsViewModel FuelsViewModel { get; }
        public ClientViewModel ClientViewModel { get; }

        public MainViewModel(FuelsViewModel fuelsViewModel, ClientViewModel clientViewModel, SupplierViewModel supplierViewModel, SaleViewModel saleViewModel)
        {
            FuelsViewModel = fuelsViewModel;
            ClientViewModel = clientViewModel;
            SupplierViewModel = supplierViewModel;
            SaleViewModel = saleViewModel;
        }
    }
}
