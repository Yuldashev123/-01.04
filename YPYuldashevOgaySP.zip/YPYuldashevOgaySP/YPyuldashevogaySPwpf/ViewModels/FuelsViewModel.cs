﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using YuldashevOgayYPApiHttpClient;


namespace YPyuldashevogaySPwpf.ViewModels
{
    public class FuelsViewModel : BaseViewModel
    { 

        private IEnumerable<Fuel> _Fuel;
        public IEnumerable<Fuel> Fuels

        {
            get { return _Fuel; }
            set { _Fuel = value; OnPropertyChanged(); }
        }
        //Временный объект для добавления или изменения
        private Fuel _CurrentFuel;
        public Fuel CurrentFuel
        {
            get { return _CurrentFuel; }
            set { _CurrentFuel = value; OnPropertyChanged(); }
        }
        public DelegateCommand ProcessFuelCommand
        {
            get
            {
                return new DelegateCommand(o =>
                {
                    ProcessFuel();
                });
            }
        }
        private void ProcessFuel()
        {
            if (CurrentFuel.FuelId == 0)
            {
                CreateFuel();
            }
            else
            {
                UpdateFuel();
            }
        }
        public DelegateCommand ClearFuelCommand
        {
            get
            {
                return new DelegateCommand(o =>
                {
                    ClearFuel();
                });
            }
        }
        private void ClearFuel()
        {
            CurrentFuel = new Fuel();
        }
        private void UpdateFuel()
        {
            _httpClient.UpdateAsync(CurrentFuel);
            ClearFuel();
            GetFuel();
        }
        private void CreateFuel()
        {
            _httpClient.CreateAsync(CurrentFuel);
            ClearFuel();
            GetFuel();
        }
        private void DeleteFuel(int FuelId)
        {
            _httpClient.DeleteAsync(FuelId);
            GetFuel();
        }
        public DelegateCommand DeleteFuelCommand
        {
            get
            {
                return new DelegateCommand(o =>
                {
                    DeleteFuel((int)o);
                });
            }
        }
        private void GetFuel()
        {
            Fuels = _httpClient.GetAllAsync().Result;
        }

        private FuelsHttpClient _httpClient;

        public FuelsViewModel(FuelsHttpClient httpClient)
        {
            _httpClient = httpClient;
            GetFuel();
            ClearFuel();
        }
    }
}
