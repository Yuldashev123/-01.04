﻿
using Microsoft.EntityFrameworkCore;
using System.IO;
using YPYuldashevOgaySP.Models;

namespace YPYuldashevOgaySP.Contexts
{
    namespace YPYuldashevOgaySP.Contexts
    {
        public class Context : DbContext
        {
            public DbSet<Client> Clients { get; set; }
            public DbSet<Fuel> Fuels { get; set; }
            public DbSet<Sale> Sales { get; set; }
            public DbSet<Supplier> Suppliers { get; set; }

            public Context(DbContextOptions<Context> options)
                : base(options)
            {
                Database.EnsureCreated();
            }
        }
    }
}
