﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using YPYuldashevOgaySP.Contexts.YPYuldashevOgaySP.Contexts;
using YPYuldashevOgaySP.Models;

namespace YPYuldashevOgaySP.Controllers
{
    [ApiController]
    [Route("API/[controller]")]
    public class ClientsController : ControllerBase
    {
        private IDbContextFactory<Context> _contextFactory;
        public ClientsController(IDbContextFactory<Context> contextFactory)
        {
            _contextFactory = contextFactory;
        }
        /// <summary>
        /// Все записи
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public async Task<IEnumerable<Client>> GetAll()
        {
            Context context = _contextFactory.CreateDbContext();
            return await context.Clients.ToListAsync();
        }
        /// <summary>
        /// Добавление данных
        /// </summary>
        /// <returns></returns>
        [HttpPost]
        public async Task Create([FromBody] Client clients)
        {
            Context context = _contextFactory.CreateDbContext();
            await context.Clients.AddAsync(clients);
            await context.SaveChangesAsync();
        }

        /// <summary>
        /// Удаление клиентов
        /// </summary>
        /// <returns></returns>
       
        [HttpDelete("{id}")]
        public async Task Delete(int id)
        {
            Context context = _contextFactory.CreateDbContext();
            Client ClientForDelete = await context.Clients.FindAsync(id);
            context.Clients.Remove(ClientForDelete);
            await context.SaveChangesAsync();
        }

        /// <summary>
        /// Поиск по id
        /// </summary>
        /// <returns></returns>

        [HttpGet("{id}")]
        public async Task<Client> Get(int id)
        {
            Context context = _contextFactory.CreateDbContext();
            return await context.Clients.FindAsync(id);
        }

        /// <summary>
        /// Поиск по наименованию
        /// </summary>
        /// <returns></returns>

        [HttpGet("ByFullname/{Fullname}")]

        public async Task<IEnumerable<Client>> GetByFullname(string Fullname)
        {
            Context context = _contextFactory.CreateDbContext();
            return await context.Clients.Where(Fuel => Fuel.Fullname == Fullname).ToListAsync();
        }

        /// <summary>
        /// Обновление данных
        /// </summary>
        /// <returns></returns>

        [HttpPut]
        public async Task Update([FromBody] Client client)
        {
            Context context = _contextFactory.CreateDbContext();
            context.Clients.Update(client);
            await context.SaveChangesAsync();
        }

    }
}
