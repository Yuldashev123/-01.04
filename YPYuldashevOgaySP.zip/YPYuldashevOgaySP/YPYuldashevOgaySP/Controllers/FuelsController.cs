﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using YPYuldashevOgaySP.Contexts.YPYuldashevOgaySP.Contexts;
using YPYuldashevOgaySP.Models;

namespace YPYuldashevOgaySP.Controllers
{
    [ApiController]
    [Route("API/[controller]")]
    public class FuelsController : ControllerBase
    {
        private IDbContextFactory<Context> _contextFactory;
        public FuelsController(IDbContextFactory<Context> contextFactory)
        {
            _contextFactory = contextFactory;
        }

        /// <summary>
        /// Все записи
        /// </summary>
        /// <returns></returns>

        [HttpGet]
        public async Task<IEnumerable<Fuel>> GetAll()
        {
            Context context = _contextFactory.CreateDbContext();
            return await context.Fuels.ToListAsync();
        }

        /// <summary>
        /// Добавление данных
        /// </summary>
        /// <returns></returns>
        /// 
        [HttpPost]
        public async Task Create([FromBody] Fuel fuels)
        {
            Context context = _contextFactory.CreateDbContext();
            await context.Fuels.AddAsync(fuels);
            await context.SaveChangesAsync();
        }

        /// <summary>
        /// Удаление
        /// </summary>
        /// <returns></returns>

        [HttpDelete("{id}")]
        public async Task Delete(int id)
        {
            Context context = _contextFactory.CreateDbContext();
            Fuel fuelForDelete = await context.Fuels.FindAsync(id);
            context.Fuels.Remove(fuelForDelete);
            await context.SaveChangesAsync();
        }

        /// <summary>
        /// Поиск по id
        /// </summary>
        /// <returns></returns>
        /// 
        [HttpGet("{id}")]
        public async Task<Fuel> Get(int id)
        {
            Context context = _contextFactory.CreateDbContext();
            return await context.Fuels.FindAsync(id);
        }

        /// <summary>
        /// Поиск по наименованию
        /// </summary>
        /// <returns></returns>

        [HttpGet("ByFullname/{Fullname}")]

        public async Task<IEnumerable<Fuel>> GetByFullname(string Fullname)
        {
            Context context = _contextFactory.CreateDbContext();
            return await context.Fuels.Where(Fuel => Fuel.Fullname == Fullname).ToListAsync();
        }

        /// <summary>
        /// Обновление данных
        /// </summary>
        /// <returns></returns>

        [HttpPut]
        public async Task Update([FromBody] Fuel fuel)
        {
            Context context = _contextFactory.CreateDbContext();
            context.Fuels.Update(fuel);
            await context.SaveChangesAsync();
        }

    }
}
