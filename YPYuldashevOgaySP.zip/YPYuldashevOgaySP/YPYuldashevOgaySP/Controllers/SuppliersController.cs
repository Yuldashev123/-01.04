﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using YPYuldashevOgaySP.Contexts.YPYuldashevOgaySP.Contexts;
using YPYuldashevOgaySP.Models;

namespace YPYuldashevOgaySP.Controllers
{
    [ApiController]
    [Route("API/[controller]")]
    public class SuppliersController : ControllerBase
    {
        private IDbContextFactory<Context> _contextFactory;
        public SuppliersController(IDbContextFactory<Context> contextFactory)
        {
            _contextFactory = contextFactory;
        }

        /// <summary>
        /// Все записи
        /// </summary>
        /// <returns></returns>

        [HttpGet]
        public async Task<IEnumerable<Supplier>> GetAll()
        {
            Context context = _contextFactory.CreateDbContext();
            return await context.Suppliers.ToListAsync();
        }

        /// <summary>
        /// Добавление данных
        /// </summary>
        /// <returns></returns>
        
        [HttpPost]
        public async Task Create([FromBody] Supplier suppliers)
        {
            Context context = _contextFactory.CreateDbContext();
            await context.Suppliers.AddAsync(suppliers);
            await context.SaveChangesAsync();
        }

        /// <summary>
        /// Удаление
        /// </summary>
        /// <returns></returns>
        
        [HttpDelete("{id}")]
        public async Task Delete(int id)
        {
            Context context = _contextFactory.CreateDbContext();
            Supplier supplierForDelete = await context.Suppliers.FindAsync(id);
            context.Suppliers.Remove(supplierForDelete);
            await context.SaveChangesAsync();
        }

        /// <summary>
        /// Поиск по id
        /// </summary>
        /// <returns></returns>
        

        [HttpGet("{id}")]
        public async Task<Supplier> Get(int id)
        {
            Context context = _contextFactory.CreateDbContext();
            return await context.Suppliers.FindAsync(id);
        }

        /// <summary>
        /// Поиск по наименованию
        /// </summary>
        /// <returns></returns>

        [HttpGet("ByFullname/{Fullname}")]

        public async Task<IEnumerable<Supplier>> GetByFullname(string Fullname)
        {
            Context context = _contextFactory.CreateDbContext();
            return await context.Suppliers.Where(Supplier => Supplier.Fullname == Fullname).ToListAsync();
        }

        /// <summary>
        /// Обновление данных
        /// </summary>
        /// <returns></returns>

        [HttpPut]
        public async Task Update([FromBody] Supplier supplier)
        {
            Context context = _contextFactory.CreateDbContext();
            context.Suppliers.Update(supplier);
            await context.SaveChangesAsync();
        }

    }
}
