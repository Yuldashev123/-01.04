﻿using System.IO;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using YPYuldashevOgaySP.Contexts.YPYuldashevOgaySP.Contexts;
using YPYuldashevOgaySP.Models;

namespace YPYuldashevOgaySP.Controllers
{

    [ApiController]
    [Route("API/[controller]")]
    public class SalesController : ControllerBase
    {
        private IDbContextFactory<Context> _contextFactory;
        public SalesController(IDbContextFactory<Context> contextFactory)
        {
            _contextFactory = contextFactory;
        }

        /// <summary>
        /// Все записи
        /// </summary>
        /// <returns></returns>

        [HttpGet]
        public async Task<IEnumerable<Sale>> GetAll()
        {
            Context context = _contextFactory.CreateDbContext();
            return await context.Sales.ToListAsync();
        }

        /// <summary>
        /// Добавление данных
        /// </summary>
        /// <returns></returns>

        [HttpPost]
        public async Task Create([FromBody] Sale sales)
        {
            Context context = _contextFactory.CreateDbContext();
            await context.Sales.AddAsync(sales);
            await context.SaveChangesAsync();
        }

        /// <summary>
        /// Удаление
        /// </summary>
        /// <returns></returns>

        [HttpDelete("{id}")]
        public async Task Delete(int id)
        {
            Context context = _contextFactory.CreateDbContext();
            Sale saleForDelete = await context.Sales.FindAsync(id);
            context.Sales.Remove(saleForDelete);
            await context.SaveChangesAsync();
        }

        /// <summary>
        /// Поиск по id
        /// </summary>
        /// <returns></returns>
        
        [HttpGet("{id}")]
        public async Task<Sale> Get(int id)
        {
            Context context = _contextFactory.CreateDbContext();
            return await context.Sales.FindAsync(id);
        }

        /// <summary>
        /// Поиск по наименованию
        /// </summary>
        /// <returns></returns>

        [HttpGet("ByVolume/{Volume}")]

        public async Task<IEnumerable<Sale>> GetByFullname(string Volume)
        {
            Context context = _contextFactory.CreateDbContext();
            return await context.Sales.Where(Sale => Sale.Volume == Volume).ToListAsync();
        }


        /// <summary>
        /// Поиск по дате
        /// </summary>
        /// <returns></returns>

        [HttpGet("ByDate/{date}")]
        public async Task<IEnumerable<Sale>> Get(DateTime date)
        {
            Context context = _contextFactory.CreateDbContext();
            return await context.Sales.Where(DateOfSale =>
            DateOfSale.DateOfSale.Date == date).ToListAsync();
        }

        /// <summary>
        /// Обновление данных
        /// </summary>
        /// <returns></returns>

        [HttpPut]
        public async Task Update([FromBody] Sale sale)
        {
            Context context = _contextFactory.CreateDbContext();
            context.Sales.Update(sale);
            await context.SaveChangesAsync();
        }

    }

}
