﻿namespace YPYuldashevOgaySP.Models
{
    public class Supplier
    {
        public int SupplierId { get; set; }
        public string Fullname { get; set;}
        public string Phone { get; set;}
        public string LegalAddress { get; set;}
    }
}
