﻿namespace YPYuldashevOgaySP.Models
{
    public class Fuel
    {
      public int  FuelId { get; set; }
      public string Fullname { get; set;}
      public string TypeOfFuel { get; set;}
      public string Price { get; set;}
      public int SupplierId { get; set; }

    }
}
