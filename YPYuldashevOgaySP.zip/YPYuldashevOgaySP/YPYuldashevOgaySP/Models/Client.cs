﻿namespace YPYuldashevOgaySP.Models
{
    public class Client
    {
        public int ClientId { get; set; }
        public string Fullname { get; set; }
        public  string Phone {  get; set; }

    }
}
