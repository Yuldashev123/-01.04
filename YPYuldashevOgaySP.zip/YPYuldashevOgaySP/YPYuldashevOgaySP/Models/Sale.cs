﻿namespace YPYuldashevOgaySP.Models
{
    public class Sale
    {
        public int SaleId { get; set; }
        public string Volume { get; set;}
        public string Amount { get; set;}
        public DateTime DateOfSale { get; set; }
        public string CheckNumber { get; set; }
        public int ClientId { get; set; }
        public int FuelId { get; set; }

    }
}
