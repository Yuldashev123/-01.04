﻿using YuldashevApiHttpClient;
const string ApiUrl = "http://localhost:5000";
HttpClient client = new HttpClient();
ActorsHttpClient actorsHttpClient = new ActorsHttpClient(ApiUrl,client);
IEnumerable<Actor> actors = actorsHttpClient.GetAllAsync().Result;
foreach (Actor actor in actors)
{
    Console.WriteLine("|{0,10},{1},{2}|", actor.Fullname,actor.DateOfBirth,actor.Country,actor.NamberOfFilms);
}