﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using YuldashevPr5SP.Contexts.YuldashevPr5SP.Contexts;
using YuldashevPr5SP.Models;

namespace YuldashevPr5SP.Controllers
{
    [ApiController]
    [Route("API/[controller]")]
    public class ActorsController : ControllerBase
    {
        private IDbContextFactory<Context> _contextFactory;
        public ActorsController(IDbContextFactory<Context> contextFactory)
        {
            _contextFactory = contextFactory;
        }

        [HttpGet]
        public async Task<IEnumerable<Actor>> GetAll()
        {
            Context context = _contextFactory.CreateDbContext();
            return await context.Actors.ToListAsync();
        }

        [HttpPost]
        public async Task Create([FromBody] Actor actors)
        {
            Context context = _contextFactory.CreateDbContext();
            await context.Actors.AddAsync(actors);
            await context.SaveChangesAsync();
        }

        [HttpDelete("{id}")]
        public async Task Delete(int id)
        {
            Context context = _contextFactory.CreateDbContext();
            Actor actorForDelete = await context.Actors.FindAsync(id);
            context.Actors.Remove(actorForDelete);
            await context.SaveChangesAsync();
        }

        [HttpGet("{id}")]
        public async Task<Actor> Get(int id)
        {
            Context context = _contextFactory.CreateDbContext();
            return await context.Actors.FindAsync(id);
        }

        [HttpGet("Byfullname/")]
        public async Task<IEnumerable<Actor>> GetByfullname()
        {
            Context context = _contextFactory.CreateDbContext();
            return await context.Actors.Where(actors =>
            actors.fullname.StartsWith("Д")).ToListAsync();
        }

        [HttpGet("ByDate/{date}")]
        public async Task<IEnumerable<Actor>> Get(DateTime date)
        {
            Context context = _contextFactory.CreateDbContext();
            return await context.Actors.Where(DateOfBirth =>
            DateOfBirth.DateOfBirth.Date == date).ToListAsync();
        }
    }
}
