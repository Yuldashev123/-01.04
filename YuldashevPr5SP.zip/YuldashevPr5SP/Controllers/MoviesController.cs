﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using YuldashevPr5SP.Contexts.YuldashevPr5SP.Contexts;
using YuldashevPr5SP.Models;

namespace YuldashevPr5SP.Controllers
{
    [ApiController]
    [Route("API/[controller]")]
    public class MoviesController : ControllerBase
    {
        private IDbContextFactory<Context> _contextFactory;
        public MoviesController(IDbContextFactory<Context> contextFactory)
        {
            _contextFactory = contextFactory;
        }

        [HttpGet]
        public async Task<IEnumerable<Movie>> GetAll()
        {
            Context context = _contextFactory.CreateDbContext();
            return await context.movies.ToListAsync();
        }

        [HttpPost]
        public async Task Create([FromBody] Movie movie)
        {
            Context context = _contextFactory.CreateDbContext();
            await context.movies.AddAsync(movie);
            await context.SaveChangesAsync();
        }

        [HttpDelete("{id}")]
        public async Task Delete(int id)
        {
            Context context = _contextFactory.CreateDbContext();
            Movie movieForDelete = await context.movies.FindAsync(id);
            context.movies.Remove(movieForDelete);
            await context.SaveChangesAsync();
        }

        [HttpGet("{id}")]
        public async Task<Movie> Get(int id)
        {
            Context context = _contextFactory.CreateDbContext();
            return await context.movies.FindAsync(id);
        }

        [HttpGet("ByTitle/")]
        public async Task<IEnumerable<Movie>> GetByTitle()
        {
            Context context = _contextFactory.CreateDbContext();
            return await context.movies.Where(movie =>
            movie.title.StartsWith("Дю")).ToListAsync();
        }

        [HttpGet("ByDate/{date}")]
        public async Task<IEnumerable<Movie>> Get(DateTime date)
        {
            Context context = _contextFactory.CreateDbContext();
            return await context.movies.Where(release =>
            release.release.Date == date).ToListAsync();
        }

        [HttpGet("ByRating/{rating}")]
        public async Task<IEnumerable<Movie>> GetByRating(double rating)
        {
            Context context = _contextFactory.CreateDbContext();
            return await context.movies.Where(Movie =>
            Movie.Rating > rating).ToListAsync();
        }


        //Вывод фильмов по стране
        [HttpGet("ByCountry/{country}")]
        public async Task<IEnumerable<Movie>> GetByCountry(string country)
        {
            Context context = _contextFactory.CreateDbContext();
            return await context.movies.Where(Movie =>
            Movie.Country.ToLower() == country).ToListAsync();
        }
    }
}
