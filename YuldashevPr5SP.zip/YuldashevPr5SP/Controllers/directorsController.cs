﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using YuldashevPr5SP.Contexts.YuldashevPr5SP.Contexts;
using YuldashevPr5SP.Models;

namespace YuldashevPr5SP.Controllers
{
    [ApiController]
    [Route("API/[controller]")]
    public class DirectorsController : ControllerBase
    {
        private IDbContextFactory<Context> _contextFactory;
        public DirectorsController(IDbContextFactory<Context> contextFactory)
        {
            _contextFactory = contextFactory;
        }

        [HttpGet]
        public async Task<IEnumerable<Director>> GetAll()
        {
            Context context = _contextFactory.CreateDbContext();
            return await context.directors.ToListAsync();
        }

        [HttpPost]
        public async Task Create([FromBody] Director director)
        {
            Context context = _contextFactory.CreateDbContext();
            await context.directors.AddAsync(director);
            await context.SaveChangesAsync();
        }

        [HttpDelete("{id}")]
        public async Task Delete(int id)
        {
            Context context = _contextFactory.CreateDbContext();
            Director directorForDelete = await context.directors.FindAsync(id);
            context.directors.Remove(directorForDelete);
            await context.SaveChangesAsync();
        }

        [HttpGet("{id}")]
        public async Task<Director> Get(int id)
        {
            Context context = _contextFactory.CreateDbContext();
            return await context.directors.FindAsync(id);
        }

        [HttpGet("Byfullname/")]
        public async Task<IEnumerable<Director>> GetByfullname()
        {
            Context context = _contextFactory.CreateDbContext();
            return await context.directors.Where(directors =>
            directors.fullname.StartsWith("Д")).ToListAsync();
        }

        [HttpGet("ByDate/{date}")]
        public async Task<IEnumerable<Director>> Get(DateTime date)
        {
            Context context = _contextFactory.CreateDbContext();
            return await context.directors.Where(DateOfBirth =>
            DateOfBirth.DateOfBirth.Date == date).ToListAsync();
        }
    }
}
