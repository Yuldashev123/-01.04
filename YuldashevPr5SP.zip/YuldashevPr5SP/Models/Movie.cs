﻿namespace YuldashevPr5SP.Models
{
    public class Movie
    {
        public int movieid { get; set; }
        public int directorid { get; set; }
        public string title { get; set; }
        public DateTime release { get; set; }
        public double Rating { get; set; }
        public string Country { get; set; }
    }
}
