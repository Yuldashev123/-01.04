﻿namespace YuldashevPr5SP.Models
{
    public class Director
    {
        public int directorid { get; set; }

        public string fullname { get; set; }

        public int NamberOfFilms { get; set; }

        public DateTime DateOfBirth { get; set; }

        public string Country { get; set; }
    }
}

