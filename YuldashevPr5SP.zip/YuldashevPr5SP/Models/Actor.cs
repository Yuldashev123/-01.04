﻿namespace YuldashevPr5SP.Models
{
    public class Actor
    {
        public int Actorid { get; set; }

        public int movieid { get; set; }

        public string fullname { get; set; }

        public DateTime DateOfBirth { get; set; }

        public string Country { get; set; }

        public int NamberOfFilms { get; set; }
        
    }
}

