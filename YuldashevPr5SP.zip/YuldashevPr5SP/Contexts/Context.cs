﻿using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;
using YuldashevPr5SP.Models;


namespace YuldashevPr5SP.Contexts
{
    namespace YuldashevPr5SP.Contexts
    {
        public class Context : DbContext
        {
            public DbSet<Director> directors { get; set; }
            public DbSet<Movie> movies { get; set; }
            public DbSet<Actor> Actors { get; set; }
            public Context(DbContextOptions<Context> options)
                : base(options)
            {
                Database.EnsureCreated();
            }
        }
    }

}